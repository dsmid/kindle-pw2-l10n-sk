browserStrings	
http://en.wikipedia.org/	
http://m.facebook.com/	
http://m.gmail.com/	
http://m.yahoo.com/mail?.intl=gb	
http://mobile.twitter.com/	
http://news.bbc.co.uk/	
http://uk.imdb.com/	
http://uk.yahoo.com/	
http://www.amazon.co.uk/	
http://www.dailymail.co.uk/	
http://www.google.co.uk/	
http://www.google.co.uk/search?q=	
s go function	
strings', 'object	
