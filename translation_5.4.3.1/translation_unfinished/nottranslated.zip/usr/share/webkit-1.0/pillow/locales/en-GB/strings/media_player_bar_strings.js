0 {right} 0 0	
{width}px	
