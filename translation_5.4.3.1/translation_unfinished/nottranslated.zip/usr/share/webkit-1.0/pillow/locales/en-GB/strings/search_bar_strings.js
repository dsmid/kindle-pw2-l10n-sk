http://baike.baidu.com/search/word?&pic=1&enc=utf8&word=	
http://en.wikipedia.org/w/index.php?title=Special%3ASearch&search=	
http://www.baidu.com/s?tn=baiduhome_pg&ie=utf-8&rn=4&wd=	
http://www.douban.com/search?q=	
http://www.google.co.uk/search?q=	
