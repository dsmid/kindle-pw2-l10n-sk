&#9654	
Advanced	
Auto Brightness	
In brightly lit rooms, use a <u>high</u> setting.	
Max.	
Off	
On	
Recommended for Bright Rooms	
Recommended for Dark Rooms	
Recommended for Dim Rooms	
Recommended for Overcast Conditions	
Recommended for Sunlight	
Use a low setting for dark rooms.	
