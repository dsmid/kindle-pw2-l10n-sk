Advanced Options	
Advanced	
Are you sure you want to forget the Wi-Fi network "{essid}"?	
Available Networks	
CA Certificate	
Cancel	
Connect	
Connected	
Connecting	
Connection Failed	
Connection Type	
DHCP	
DNS	
Disconnect	
Done	
EAP Method	
Enter Again	
Enter Other Wi-Fi Network	
Enter Wi-Fi Network	
Enterprise	
Error	
Forget Network?	
Forget	
Hide Password	
IP Address	
Incorrect Password	
MSCHAPv2	
Network Name Too Long	
Network Name	
No Wi-Fi networks were found	
None	
OK	
Other...	
PAP	
PEAP	
Password Too Long	
Password Too Short	
Password	
Personal	
Phase 2 Authentication	
Rescan	
Router	
Scan Complete	
Scanning for Networks	
Security Error	
Security Type	
Set Up	
Static	
Subnet Mask	
TTLS	
The security certificate cannot be located. Please verify that the name is correct and try again.	
Try Again	
Unable to Find Certificate	
Unable to delete profile for Wi-Fi network "{essid}".	
Unable to set up the Wi-Fi network "{essid}". The network information you entered is incomplete. Please check network configuration and try setting up the network again. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
Unsupported Network	
Username	
Version	
WEP	
WPA/WPA2	
WPA2	
WPS	
Wi-Fi Error	
Wi-Fi Login	
Wi-Fi Networks ({numNetworks})	
Wi-Fi Not Configured	
Wi-Fi Password Required	
You can set up the Wi-Fi network connection and security options for the network named below.	
Your Kindle connected to the Wi-Fi network but could not reach the Internet. Contact your Internet Service Provider for further assistance.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}" using WPS. Please check that the WPS button was tapped.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}" using WPS. Would you like to set up this network manually?	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". --"{error}"--. Press Set Up to enter your password again or set up your network manually. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". Check that your security settings are correct and try again.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". Enterprise Wi-Fi networks are not supported on Kindle. Try connecting to another network. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". Peer-to-peer Wi-Fi networks are not supported on Kindle. Try connecting to another network. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". Please check your credentials or contact your system administrator.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". Press Set Up to enter your password again or set up your network manually. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". Tap the Home button, then connect to Wi-Fi again. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". The access point rejected the connection request. Check your routerʼs MAC address filtering settings and try again.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". The network name is too long. Would you like to set up this network manually?	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". The password you entered is incorrect. Try entering your password again or setting up your network manually. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". The password you entered is longer than allowed by the Wi-Fi network. Try entering your password again. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". The password you entered is missing one or more characters. Try entering your password again. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". The security type you entered does not match the security type of the Wi-Fi network. Please set up the network manually again and select the correct security type. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
Your Kindle is unable to connect to the Wi-Fi network "{essid}". Try entering your username and password again. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
Your Kindle is unable to connect to the Wi-Fi network. This network is not configured. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
Your Kindle is unable to connect to your local network "{essid}". You may need to check your local network. If you have issues connecting your Kindle to Wi-Fi, you can find help at www.kindle.com/support.	
